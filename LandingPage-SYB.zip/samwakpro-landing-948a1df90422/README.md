
# Say Your Bet - Landing page :smiley:

## Pour acceder � la page web : 

1. Ouvrir le terminal, accedez au fichier sur l'ordinateur, et tapez `npm install` 
2. Dans ce m�me terminal, tapez `npm start`
3. Ouvrir un autre terminal, accedez au fichier sur l'ordinateur, et tapez `npm run bundle` 

