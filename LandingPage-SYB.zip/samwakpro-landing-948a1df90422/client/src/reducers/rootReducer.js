import { combineReducers } from 'redux';
import translationReducer from './reducer';

//rootReducer use combineReducers form Redux : to combine all the functions of several reducers
//Here only one reducer exists : reducer.js
export const rootReducer = combineReducers({
  translation: translationReducer,
});
