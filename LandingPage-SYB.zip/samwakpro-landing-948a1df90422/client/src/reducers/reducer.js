
export const initialState = {
  locale: 'en_US', // default locale
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case 'SET_LANGUAGE':
      return { ...state, locale: action.locale };
    default: 
      return state;
  }
}

