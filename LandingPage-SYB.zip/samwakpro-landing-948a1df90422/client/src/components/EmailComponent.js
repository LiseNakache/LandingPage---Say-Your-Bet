import React from 'react';
import axios from 'axios'
import { PropTypes } from 'prop-types';
import TranslationContainer from './Translation/TranslationContainer';

class EmailComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = { emailAdress: "" }
        this.handleSubmit = this.handleSubmit.bind(this)
        this.handleChange = this.handleChange.bind(this)
    }

    // When the button SUBMIT is clicked --> Axios.Post//
    handleSubmit(event) {
        event.preventDefault();

        axios({
            method: 'post',
            url: 'https://apitest.sayourbet.com/v1/subscriptions/add/',
            data: {
                email: this.state.emailAdress,
            },
            withCredentials: true,
            // proxy: {
            //     host: '127.0.0.1',
            //     port: 3000,
            //     auth: {
            //         username: 'nginx',
            //         password: 'marc002'
            //     }
            //   },
            // auth: {
            //     username: 'nginx',
            //     password: 'marc002'
            // },
            responseType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
        })
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
                console.log('hey its an error')
            })
    }


    //HandleChange : the state changes everytime something is typed in the input//
    handleChange(e) {
        this.setState({ [e.target.id]: e.target.value })
        console.log(this.state)
    }

    render() {
        return (
            <div className="email">
                <h3 className="email-title"><TranslationContainer translationKey={this.props.translationKey} /></h3>
                <form onSubmit={this.handleSubmit}>
                    <div className="form-inputs input-group">
                        <input className="form-control" id="emailAdress" type="email" required="true" placeholder="Email" value={this.state.emailAdress} onChange={this.handleChange} />
                        <span className="input-group-btn">
                            <button className="btn btn-default">Submit</button>
                        </span>
                    </div>
                </form>
            </div>
        );
    }
}

export default EmailComponent;