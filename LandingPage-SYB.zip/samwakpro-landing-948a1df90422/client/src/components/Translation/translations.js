import React, { Component } from 'react';

export const TRANSLATIONS = {
  en_US: {
    about: ['Say Your Bet is a Social platform dedicated to sport betting.', <br />, 'Whether you are a sports fan, casual gamble, or sports betting expert.', <br />, 'This is the place to be !'],
    email: ['Hurry Up, write down your email, to be the first to use the app!'],
    emailButton: ['Submit'],
    emailPlaceholder: ['Your Email'],
    title: ['It\'s about what you say not what you bet !'],
    reasons: ['3 reasons to join'],
    //reason
    firstTitle: ['Transparency'],
    secondTitle: ['Sport oriented Statistics'],
    thirdTitle: ['Monetize your knowledge'],
    firstParagraph: ['There is no second chance, every posted advice is tracked. ', <br />, ' You can trust everything you see.'],
    secondParagraph: ['Having financial stats on a user is fine, ', <br />, 'Knowing in which sport field he is a real expert is better!', <br />, 'We propose a complete detailed profile that shows you ...'],
    thirdParagraph: ['Start making money without betting !', <br />, 'Prove your expertise on a domain.', <br />, 'Sell your advices.', <br />, 'Better you are, more users will buy your advices.']
  },

  fr_FR: {
    about: ['Say Your Bet est une plateforme sociale dédiée au pari sportif.', <br />, 'Que vous soyez un fan de sports, un simple parieur ou un expert.', <br />, 'This is the place to be !'],
    email: ['Dépéchez vous, ', <br />, 'Notez votre email pour être l\'un des premiers à utiliser l\'application'],
    emailButton: ['Ajoutez'],
    emailPlaceholder: ['Votre Email'],
    title: ['Ce n\'est pas ce que vous dites mais ce que vous pariez'],
    reasons: ['3 raisons de rejoindre notre communauté'],
    //reason
    firstTitle: ['La Transparence'],
    secondTitle: ['Des Statistiques orientées vers le Sport'],
    thirdTitle: ['Gagnez de l\'argent grâce à vos connaissances'],
    firstParagraph: ['Il n\'y a pas de deuxième chance, chaque conseil publié est suivi.', <br />, 'Vous pouvez faire confiance à ce que vous voyez.'],
    secondParagraph: ['Obtenir des statistiques financières sur un utilisateur c\'est bien, ', <br />, 'Mais connaître le véritable expert dans chaque domaine, c\'est mieux!', <br />, 'Nous proposons un profil détaillé qui vous montre ...'],
    thirdParagraph: ['Commencez à vous faire de l\'argent sans parier !', <br />, 'Prouvez votre expertise dans un domaine.', <br />, 'Vendez vos conseils.', <br />, 'Plus d\'utilisateurs vous acheteront vos conseils, si vous êtes le meilleur.']
  },
};

export const LANG_NAMES = [
  { locale: 'en_US', name: 'EN' },
  { locale: 'fr_FR', name: 'FR' },
]
