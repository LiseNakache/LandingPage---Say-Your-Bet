import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import AboutComponent from './AboutComponent.js'
import EmailComponent from './EmailComponent';

export default class Translation extends Component {

  render() {
    return (
        <div>
    <h3>Im the translation</h3>
    <AboutComponent translation={this.props.translation} />
    {/* <EmailComponent  translation={this.props.translation} /> */}
    </div>);
  }
}

Translation.propTypes = {
  translation: PropTypes.array.isRequired,
};

//Peut être devrait appeler d'ici tous les components ??
//probleme avec les components ... Comment faire ?
//probleme avec le bouton ...