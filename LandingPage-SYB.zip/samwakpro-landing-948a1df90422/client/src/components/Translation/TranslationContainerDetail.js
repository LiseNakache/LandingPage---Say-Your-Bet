import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'react-redux';
import { TRANSLATIONS } from './translations';

class TranslationContainer extends Component {

    constructor(props) {
        super(props);
        this.state = {
            translationDetail: ''
        };
    }

    componentDidMount() {
        this._updateTranslation(this.props.translationKeyDetail, this.props.locale);
    }

    //only when change of language
    componentWillReceiveProps(nextProps) {
        if (this.props.translationKeyDetail !== nextProps.translationKeyDetail || this.props.locale !== nextProps.locale) {
            this._updateTranslation(nextProps.translationKeyDetail, nextProps.locale);
        }
    }

    _updateTranslation(translationKeyDetail, activeLanguageCode) {
        if (translationKeyDetail && activeLanguageCode) {
            try {
                this.setState({ translationDetail: TRANSLATIONS[activeLanguageCode][translationKeyDetail] });
                console.log(this.state)
            } catch (error) {
                console.log(error);
            }
        }
    }

    render() {
        if (this.state.translationDetail === '') return null;
        return (
            <div>
                {this.state.translationDetail.map((item, index) => <div key={index}> {item}</div>)}
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        locale: state.translation.locale,
    };
}


export default connect(mapStateToProps, null)(TranslationContainer);

TranslationContainer.propTypes = {
  translationKeyDetail: PropTypes.string.isRequired,
  locale: PropTypes.string,
};
