//action.js set the action for the reducer
export function setLanguage(locale) {
  return {
    type: "SET_LANGUAGE",
    locale,
  };
}