import React from 'react';
import ReasonComponent from './ReasonComponent';
import TranslationContainer from './Translation/TranslationContainer';

//REASONSCOMPONENT holds the 3 reasons//
class ReasonsComponent extends React.Component {
  constructor(props) {
    super(props)
  }

render() {
  return (
    <div className="reasons">
      <h1 className="reason-join row"><TranslationContainer translationKey={this.props.translationKey}/></h1>
      
      <div className="row">
        <ReasonComponent translationKey="firstTitle" translationKeyDetail="firstParagraph"/>
        <ReasonComponent translationKey="secondTitle" translationKeyDetail="secondParagraph"/>
        <ReasonComponent translationKey="secondTitle" translationKeyDetail="thirdParagraph"/>
      </div>
    </div>
  );
}
}

export default ReasonsComponent;
