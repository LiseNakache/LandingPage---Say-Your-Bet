import React from 'react';
import { PropTypes } from 'prop-types';
import TranslationContainer from './Translation/TranslationContainer';
class AboutComponent extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <div className="about col-md-6">
        <TranslationContainer translationKey={this.props.translationKey} />
      </div>
    )
  }
}

export default AboutComponent;

