import React from 'react';
import TranslationContainer from './Translation/TranslationContainer';
import TranslationContainerDetail from './Translation/TranslationContainerDetail';
class ReasonComponent extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="reason col-md-4">
                <h1><TranslationContainer translationKey={this.props.translationKey} /></h1>
                <h3><TranslationContainerDetail translationKeyDetail={this.props.translationKeyDetail}/></h3>
            </div>
        );
    }
}


export default ReasonComponent;