import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as translationActions from '../Translation/actions';
import LangSwitch from './LangSwitch';

class LangSwitchContainer extends Component {

  render() {
    return (
      <div>
      <LangSwitch locale={this.props.locale} setLanguage={this.props.translationActions.setLanguage} />
      </div>
    );
  }
}

//Take a piece of the application store : state and passes it into the component as a property
//The piece of the store is sent into the component as Props
// the property is the one used in combineReducers : translation --> cqfd state.translation
function mapStateToProps(state) {
  return {
    locale: state.translation.locale,
  };
}

//Take a piece of the application store : action and passes it into the component as a property
//translationActions : name of the actions exported
function mapDispatchToProps(dispatch) {
  return {
    translationActions: bindActionCreators(translationActions, dispatch),
  };
}

//connect : connect mapStateToProps to the Component
export default connect(mapStateToProps, mapDispatchToProps)(LangSwitchContainer);

LangSwitchContainer.propTypes = {
  locale: PropTypes.string,
  translationActions: PropTypes.object,
};
