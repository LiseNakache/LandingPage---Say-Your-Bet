import React from 'react';
import { render } from 'react-dom';
import ReactDom from 'react-dom';
import Header from './common/Header';
import Routes from './Routes';
import { BrowserRouter } from 'react-router-dom';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { rootReducer } from './reducers/rootReducer.js';

//Store : enable all the components to have access to the general state (translation.js)
const store = createStore(rootReducer);

//App.js calls directly MainComponent by <Routes />
class AppWrapper extends React.Component {
  render() {
    return (
      <Provider store={store}>
        <BrowserRouter>
          <div>
            <Routes />
          </div>
        </BrowserRouter>
      </Provider>
    );
  }
}

ReactDom.render(
  <AppWrapper />,
  document.getElementById('react-app'));
