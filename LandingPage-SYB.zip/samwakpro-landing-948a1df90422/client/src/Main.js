import React from 'react';
import LangSwitchContainer from './components/LangSwitch/LangSwitchContainer.js';
import AboutComponent from './components/AboutComponent';
import EmailComponent from './components/EmailComponent';
import ReasonsComponent from './components/ReasonsComponent';
import TranslationContainer from './components/Translation/TranslationContainer.js';


//MAIN COMPONENT IS THE PRINCIPAL COMPONENT THAT STARTS THE REACT TREE//
class MainComponent extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <div className="main container-fluid">
        <LangSwitchContainer />
        <div className="row logo">logo</div>

        <div className="row wrapper">
          <AboutComponent translationKey="about" />

          <div className="col-md-4 col-md-offset-2">
            <EmailComponent translationKey="email" translationKeyDetail="emailButton"  />
          </div>

        </div>

        <div className="row">
          <h4 className="main-sentence col-md-6 col-md-offset-3"><TranslationContainer translationKey="title" /></h4>
        </div>
        <hr />

        <ReasonsComponent translationKey="reasons"/>
        <EmailComponent translationKey="email"/>

      </div>

    );
  }
}

export default MainComponent;